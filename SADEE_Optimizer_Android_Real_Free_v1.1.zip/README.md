# SADEE Optimizer Android

Native Kotlin Android dashboard for Android 7.0+.

## Toolchain

- Android Gradle Plugin: 8.7.3
- Gradle: 8.9 (GitHub Actions installs it directly)
- Kotlin: 2.0.21
- Java/JDK: 17
- compileSdk/targetSdk: 35
- minSdk: 24

## What it shows

- Real device manufacturer/model
- Android version/API level
- Real total/available RAM via `ActivityManager.MemoryInfo`
- Real internal storage usage via `StatFs`
- Battery percentage via `BatteryManager`
- CPU core count and supported ABI
- Multi-page dashboard: Home, Turbo, Gaming, Cleaner, More

## Important limitation

A normal Android app cannot safely/legitimately "free all RAM", overclock CPU/GPU, or force-stop arbitrary other apps without special/system/root privileges. This project therefore does not fake those actions. It reads real system metrics and provides safe dashboard actions.

## GitHub build

1. Create a GitHub repository.
2. Upload the contents of this folder to the repository root.
3. Push to `main` or `master`, or open Actions and run **Build SADEE Optimizer APK** manually.
4. The workflow builds `app/build/outputs/apk/debug/app-debug.apk`.
5. The APK is uploaded as the workflow artifact named `SADEE-Optimizer-debug`.

## Local build

Install JDK 17 and Gradle 8.9, then run:

```bash
gradle :app:assembleDebug
```

The generated APK will be:

`app/build/outputs/apk/debug/app-debug.apk`

## Verification note

The project structure and version matrix were checked for internal consistency in this environment, but a full Android APK build was not executed here because a Gradle installation / Android SDK toolchain was not available in the execution environment. The included GitHub Actions workflow installs the required JDK, Android SDK packages, and Gradle version before building.
