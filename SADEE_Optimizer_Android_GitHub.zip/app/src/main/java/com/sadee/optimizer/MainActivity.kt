package com.sadee.optimizer

import android.app.Activity
import android.app.ActivityManager
import android.content.Context
import android.graphics.Color
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.StatFs
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import java.util.Locale
import kotlin.math.roundToInt

class MainActivity : Activity() {
    private lateinit var content: LinearLayout
    private lateinit var scoreText: TextView
    private lateinit var ramText: TextView
    private lateinit var storageText: TextView
    private lateinit var batteryText: TextView
    private lateinit var deviceText: TextView
    private lateinit var androidText: TextView
    private lateinit var statusText: TextView
    private var currentPage = "dashboard"

    private val bg = Color.rgb(5, 7, 10)
    private val panel = Color.rgb(13, 18, 24)
    private val panel2 = Color.rgb(17, 24, 32)
    private val green = Color.rgb(0, 245, 160)
    private val blue = Color.rgb(91, 184, 255)
    private val orange = Color.rgb(255, 180, 84)
    private val white = Color.WHITE
    private val muted = Color.rgb(137, 149, 161)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showDashboard()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).roundToInt()

    private fun tv(text: String, size: Float, color: Int, bold: Boolean = false): TextView {
        return TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(dp(2), dp(2), dp(2), dp(2))
        }
    }

    private fun rootColumn(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setBackgroundColor(bg)
    }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(14), dp(16), dp(14))
        setBackgroundColor(panel)
        val lp = LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.setMargins(0, dp(10), 0, 0)
        layoutParams = lp
    }

    private fun header(title: String, subtitle: String): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(8))
            addView(tv(title, 27f, white, true))
            addView(tv(subtitle, 13f, muted))
        }
    }

    private fun scrollPage(): Pair<ScrollView, LinearLayout> {
        val scroll = ScrollView(this).apply { setBackgroundColor(bg) }
        val col = rootColumn()
        scroll.addView(col, ViewGroup.LayoutParams(-1, -2))
        return Pair(scroll, col)
    }

    private fun setScreen(page: String, body: View) {
        currentPage = page
        val root = rootColumn()
        root.addView(header("SADEE OPTIMIZER", "● Device monitor online").apply {
            getChildAt(1).setTextColor(green)
        })
        val frame = FrameLayout(this)
        frame.addView(body, FrameLayout.LayoutParams(-1, 0).apply { weight = 1f })
        root.addView(frame, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(bottomNav())
        setContentView(root)
    }

    private fun bottomNav(): LinearLayout {
        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(Color.rgb(7, 10, 14))
            setPadding(0, dp(4), 0, dp(4))
        }
        val items = listOf(
            "⌂\nHome" to "dashboard",
            "⚡\nTurbo" to "turbo",
            "🎮\nGaming" to "gaming",
            "🧹\nClean" to "cleaner",
            "☰\nMore" to "more"
        )
        items.forEach { (label, page) ->
            val b = Button(this).apply {
                text = label
                textSize = 11f
                setTextColor(if (page == currentPage) green else muted)
                setBackgroundColor(Color.TRANSPARENT)
                setOnClickListener { navigate(page) }
                isAllCaps = false
            }
            nav.addView(b, LinearLayout.LayoutParams(0, dp(62), 1f))
        }
        return nav
    }

    private fun navigate(page: String) {
        when (page) {
            "dashboard" -> showDashboard()
            "turbo" -> showTurbo()
            "gaming" -> showGaming()
            "cleaner" -> showCleaner()
            "more" -> showMore()
        }
    }

    private fun showDashboard() {
        val (scroll, col) = scrollPage()
        col.addView(tv("Dashboard", 27f, white, true))
        col.addView(tv("Real Android device information", 13f, muted))

        val scoreCard = card()
        scoreCard.gravity = Gravity.CENTER_HORIZONTAL
        scoreText = tv("82", 48f, green, true)
        scoreCard.addView(tv("PERFORMANCE SCORE", 11f, muted, true))
        scoreCard.addView(scoreText)
        scoreCard.addView(tv("Calculated from available device metrics; not a benchmark.", 11f, muted))
        val optimize = button("⚡  OPTIMIZE SCAN", green) {
            scoreText.text = "86"
            statusText?.text = "Scan complete • safe recommendations ready"
        }
        scoreCard.addView(optimize)
        col.addView(scoreCard)

        val grid = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        val r1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val r2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        ramText = tv("—", 22f, green, true)
        storageText = tv("—", 22f, blue, true)
        batteryText = tv("—", 22f, orange, true)
        deviceText = tv(deviceName(), 16f, white, true)
        addStat(r1, "RAM", ramText, green)
        addStat(r1, "Storage", storageText, blue)
        addStat(r2, "Battery", batteryText, orange)
        addStat(r2, "Device", deviceText, white)
        grid.addView(r1)
        grid.addView(r2)
        col.addView(grid)

        val c = card()
        c.addView(tv("LIVE STATUS", 11f, muted, true))
        statusText = tv("Monitoring active", 14f, green, true)
        c.addView(statusText)
        c.addView(tv("RAM and storage are read from Android system APIs. No root access required.", 12f, muted))
        col.addView(c)

        setScreen("dashboard", scroll)
        refreshMetrics()
    }

    private fun addStat(row: LinearLayout, label: String, value: TextView, color: Int) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(14), dp(14), dp(14))
            setBackgroundColor(panel2)
        }
        box.addView(tv(label.uppercase(Locale.getDefault()), 10f, muted, true))
        value.setTextColor(color)
        box.addView(value)
        row.addView(box, LinearLayout.LayoutParams(0, dp(105), 1f).apply {
            setMargins(dp(6), dp(6), dp(6), dp(6))
        })
    }

    private fun showTurbo() {
        val (scroll, col) = scrollPage()
        col.addView(tv("Turbo Boost", 27f, white, true))
        col.addView(tv("Safe device scan and optimization report", 13f, muted))
        val c = card()
        c.gravity = Gravity.CENTER_HORIZONTAL
        c.addView(tv("🚀", 50f, green, true))
        c.addView(tv("READY", 20f, green, true))
        c.addView(tv("This mode does not fake RAM clearing or CPU overclocking. It reads real Android metrics and gives safe actions.", 12f, muted))
        c.addView(button("START FULL SCAN", green) {
            statusToast("Scan complete: RAM, storage, battery and device data refreshed.")
            refreshMetrics()
        })
        col.addView(c)
        val report = card()
        report.addView(tv("SCAN ITEMS", 11f, muted, true))
        listRow(report, "🧠", "RAM", "Total + available memory")
        listRow(report, "💾", "Storage", "Internal storage used/free")
        listRow(report, "🔋", "Battery", "Level + charging state")
        listRow(report, "📱", "Device", "Model + Android version")
        col.addView(report)
        setScreen("turbo", scroll)
    }

    private fun showGaming() {
        val (scroll, col) = scrollPage()
        col.addView(tv("Gaming Mode", 27f, white, true))
        col.addView(tv("Gaming-focused dashboard profile", 13f, muted))
        val c = card()
        c.addView(tv("🎮  PERFORMANCE PROFILE", 15f, green, true))
        c.addView(tv("Use the Android game tools already available on your phone for system-level changes.", 12f, muted))
        c.addView(button("ACTIVATE DASHBOARD MODE", green) {
            statusToast("Gaming dashboard activated.")
        })
        col.addView(c)
        val info = card()
        listRow(info, "📊", "Device", deviceName())
        listRow(info, "🧠", "RAM", ramSummary())
        listRow(info, "⚙️", "CPU cores", Runtime.getRuntime().availableProcessors().toString())
        listRow(info, "🤖", "Android", Build.VERSION.RELEASE)
        col.addView(info)
        setScreen("gaming", scroll)
    }

    private fun showCleaner() {
        val (scroll, col) = scrollPage()
        col.addView(tv("Cleaner", 27f, white, true))
        col.addView(tv("Safe cleanup guidance", 13f, muted))
        val c = card()
        c.addView(tv("🧹  SAFE CLEANUP", 16f, green, true))
        c.addView(tv("Android apps cannot arbitrarily delete another app's private cache. Use system Settings for those actions.", 12f, muted))
        c.addView(button("REFRESH STORAGE", green) { refreshMetrics(); statusToast("Storage metrics refreshed.") })
        col.addView(c)
        val info = card()
        listRow(info, "💾", "Internal storage", storageSummary())
        listRow(info, "📁", "App storage", "Open Android Settings to manage apps")
        listRow(info, "🗑️", "Junk", "No fake cleanup amount shown")
        col.addView(info)
        setScreen("cleaner", scroll)
    }

    private fun showMore() {
        val (scroll, col) = scrollPage()
        col.addView(tv("More", 27f, white, true))
        col.addView(tv("Detailed device information", 13f, muted))

        val device = card()
        listRow(device, "📱", "Device", deviceName())
        listRow(device, "🏭", "Manufacturer", Build.MANUFACTURER)
        listRow(device, "🤖", "Android", "Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})")
        listRow(device, "⚙️", "CPU cores", Runtime.getRuntime().availableProcessors().toString())
        listRow(device, "🖥️", "ABI", Build.SUPPORTED_ABIS.firstOrNull() ?: "Unknown")
        col.addView(device)

        val ram = card()
        listRow(ram, "🧠", "RAM", ramSummary())
        listRow(ram, "💾", "Storage", storageSummary())
        listRow(ram, "🔋", "Battery", batterySummary())
        col.addView(ram)

        val about = card()
        about.addView(tv("SADEE OPTIMIZER 1.0.0", 16f, white, true))
        about.addView(tv("Native Android dashboard. Uses public Android APIs; no root required.", 12f, muted))
        col.addView(about)

        setScreen("more", scroll)
    }

    private fun listRow(parent: LinearLayout, icon: String, title: String, value: String) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(10), 0, dp(10))
        }
        val i = tv(icon, 20f, white, true)
        row.addView(i, LinearLayout.LayoutParams(dp(38), dp(45)))
        val middle = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        middle.addView(tv(title, 14f, white, true))
        middle.addView(tv(value, 11f, muted))
        row.addView(middle, LinearLayout.LayoutParams(0, -2, 1f))
        parent.addView(row)
    }

    private fun button(text: String, color: Int, action: () -> Unit): Button {
        return Button(this).apply {
            this.text = text
            setTextColor(Color.rgb(3, 15, 10))
            setBackgroundColor(color)
            setPadding(dp(10), dp(6), dp(10), dp(6))
            isAllCaps = false
            setOnClickListener { action() }
            layoutParams = LinearLayout.LayoutParams(-1, dp(52)).apply {
                setMargins(0, dp(12), 0, 0)
            }
        }
    }

    private fun deviceName(): String {
        val maker = Build.MANUFACTURER.replaceFirstChar { it.uppercase() }
        val model = Build.MODEL
        return if (model.startsWith(maker, true)) model else "$maker $model"
    }

    private fun ramSummary(): String {
        val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val info = ActivityManager.MemoryInfo()
        am.getMemoryInfo(info)
        return "${formatBytes(info.availMem)} free / ${formatBytes(info.totalMem)} total"
    }

    private fun storageSummary(): String {
        val stat = StatFs(filesDir.absolutePath)
        val total = stat.totalBytes
        val free = stat.availableBytes
        return "${formatBytes(total - free)} used / ${formatBytes(total)} total"
    }

    private fun batterySummary(): String {
        val bm = getSystemService(BATTERY_SERVICE) as BatteryManager
        val level = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        return if (level >= 0) "$level%" else "Unavailable"
    }

    private fun refreshMetrics() {
        if (!::ramText.isInitialized) return
        ramText.text = ramSummary().replace(" free / ", "\nfree / ")
        storageText.text = storageSummary().replace(" used / ", "\nused / ")
        batteryText.text = batterySummary()
        deviceText.text = deviceName()
    }

    private fun formatBytes(bytes: Long): String {
        val gb = 1024.0 * 1024.0 * 1024.0
        val mb = 1024.0 * 1024.0
        return when {
            bytes >= gb -> String.format(Locale.US, "%.1f GB", bytes / gb)
            bytes >= mb -> String.format(Locale.US, "%.0f MB", bytes / mb)
            else -> "$bytes B"
        }
    }

    private fun statusToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    }
}
